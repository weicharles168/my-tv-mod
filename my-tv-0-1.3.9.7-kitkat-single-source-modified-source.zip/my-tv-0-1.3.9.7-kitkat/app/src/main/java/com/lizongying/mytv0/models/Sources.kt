package com.lizongying.mytv0.models

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.lizongying.mytv0.SP
import com.lizongying.mytv0.data.Global.gson
import com.lizongying.mytv0.data.Global.typeSourceList
import com.lizongying.mytv0.data.Source

class Sources {
    var version = 0

    private val _removed = MutableLiveData<Pair<Int, Int>>()
    val removed: LiveData<Pair<Int, Int>>
        get() = _removed

    private val _added = MutableLiveData<Pair<Int, Int>>()
    val added: LiveData<Pair<Int, Int>>
        get() = _added

    private val _changed = MutableLiveData<Int>()
    val changed: LiveData<Int>
        get() = _changed

    private val _sources = MutableLiveData<List<Source>>()
    val sources: LiveData<List<Source>>
        get() = _sources
    private val sourcesValue: List<Source>
        get() = _sources.value ?: emptyList()

    private val _checked = MutableLiveData<Int>()
    val checked: LiveData<Int>
        get() = _checked
    val checkedValue: Int
        get() = _checked.value ?: DEFAULT_CHECKED

    fun setChecked(position: Int) {
        _checked.value = position
    }

    fun setSourceChecked(position: Int, checked: Boolean): Boolean {
        val checkedBefore = getSource(position)?.checked
        if (checkedBefore == checked) {
            return false
        } else {
            getSource(position)?.checked = checked
//            if (checked) {
//                Log.i(TAG, "setChecked $position")
//                setChecked(position)
//            }
//
//            SP.sources = gson.toJson(sources, type) ?: ""
            return true
        }
    }

    private fun setSources(sources: List<Source>) {
        // 单源版：只保留当前用户自定义的一个源，避免默认/后台源自动追加。
        val single = sources.take(1).mapIndexed { index, source ->
            source.apply { checked = index == 0 }
        }
        _sources.value = single
        _checked.value = if (single.isNotEmpty()) 0 else DEFAULT_CHECKED
        SP.sources = gson.toJson(single, typeSourceList) ?: ""
    }

    fun addSource(source: Source) {
        // 单源版：新增/导入源时直接覆盖历史源，不再 add/merge/append。
        val single = source.apply { checked = true }
        _sources.value = listOf(single)
        _checked.value = 0
        SP.sources = gson.toJson(listOf(single), typeSourceList) ?: ""
        _changed.value = version
        version++
    }

    fun removeSource(id: String): Boolean {
        if (sourcesValue.isEmpty()) {
            Log.i(TAG, "sources is empty")
            return false
        }

        val index = sourcesValue.indexOfFirst { it.id == id }
        if (index != -1) {
            val newSources = sourcesValue.toMutableList().apply {
                removeAt(index)
            }
            _sources.value = newSources
            _checked.value = if (newSources.isNotEmpty()) 0 else DEFAULT_CHECKED
            SP.sources = gson.toJson(newSources, typeSourceList) ?: ""
            if (newSources.isEmpty()) {
                SP.configUrl = ""
            }

            _removed.value = Pair(index, version)
            version++
            return true
        }

        Log.i(TAG, "sourceId is not exists")
        return false
    }

    fun getSource(idx: Int): Source? {
        if (idx < 0 || idx >= size()) {
            return null
        }

        return sourcesValue[idx]
    }

    fun init() {
        // 单源版：不读取 res/raw/sources.txt 中的后台/推荐源；只读取用户保存过的源。
        val savedSources = SP.sources
        if (!savedSources.isNullOrEmpty()) {
            try {
                val sources: List<Source> = gson.fromJson(savedSources, typeSourceList)
                setSources(sources.filter { it.uri.isNotBlank() })
            } catch (e: Exception) {
                e.printStackTrace()
                SP.sources = ""
                _sources.value = emptyList()
                _checked.value = DEFAULT_CHECKED
            }
        } else if (!SP.configUrl.isNullOrBlank()) {
            setSources(listOf(Source(uri = SP.configUrl!!, checked = true)))
        } else {
            _sources.value = emptyList()
            _checked.value = DEFAULT_CHECKED
        }

        _changed.value = version
        version++
    }

    init {
        init()
    }

    fun size(): Int {
        return sourcesValue.size
    }

    companion object {
        const val TAG = "Sources"
        const val DEFAULT_CHECKED = -1
    }
}